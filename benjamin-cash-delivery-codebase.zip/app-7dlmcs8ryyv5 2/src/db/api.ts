import { supabase } from "./supabase";
import type { Profile, Invitation, Order, OrderWithDetails, InvitationWithDetails, UserRole, OrderStatus, FeeCalculation, OrderEventWithDetails, CustomerAddress, AddressSnapshot } from "@/types/types";

// Fee Calculation
export function calculateFees(requestedAmount: number): FeeCalculation {
  const profit = Math.max(3.50, 0.02 * requestedAmount);
  const complianceFee = (0.0101 * requestedAmount) + 1.90;
  const deliveryFee = 8.16;
  const totalServiceFee = profit + complianceFee + deliveryFee;
  const totalPayment = requestedAmount + totalServiceFee;

  return {
    requestedAmount,
    profit: Number(profit.toFixed(2)),
    complianceFee: Number(complianceFee.toFixed(2)),
    deliveryFee: Number(deliveryFee.toFixed(2)),
    totalServiceFee: Number(totalServiceFee.toFixed(2)),
    totalPayment: Number(totalPayment.toFixed(2))
  };
}

// Profile APIs
export async function getCurrentProfile(): Promise<Profile | null> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;

  const { data, error } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", user.id)
    .maybeSingle();

  if (error) {
    console.error("Error fetching profile:", error);
    return null;
  }

  return data;
}

export async function updateCurrentProfile(updates: {
  first_name?: string;
  last_name?: string;
  phone?: string | null;
  email?: string;
}): Promise<boolean> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return false;

  const { error } = await supabase
    .from("profiles")
    .update(updates)
    .eq("id", user.id);

  if (error) {
    console.error("Error updating profile:", error);
    return false;
  }

  return true;
}

export async function updateProfile(id: string, updates: Partial<Profile>): Promise<Profile | null> {
  const { data, error } = await supabase
    .from("profiles")
    .update(updates)
    .eq("id", id)
    .select()
    .maybeSingle();

  if (error) {
    console.error("Error updating profile:", error);
    throw error;
  }

  return data;
}

export async function getAllProfiles(): Promise<Profile[]> {
  const { data, error } = await supabase
    .from("profiles")
    .select("*")
    .order("created_at", { ascending: false });

  if (error) {
    console.error("Error fetching profiles:", error);
    return [];
  }

  return Array.isArray(data) ? data : [];
}

export async function getProfilesByRole(role: UserRole): Promise<Profile[]> {
  const { data, error } = await supabase
    .from("profiles")
    .select("*")
    .contains("role", [role])
    .order("created_at", { ascending: false });

  if (error) {
    console.error("Error fetching profiles by role:", error);
    return [];
  }

  return Array.isArray(data) ? data : [];
}

export async function assignRole(userId: string, role: UserRole): Promise<boolean> {
  const { data: profile } = await supabase
    .from("profiles")
    .select("role")
    .eq("id", userId)
    .maybeSingle();

  if (!profile) return false;

  const currentRoles = profile.role || [];
  if (currentRoles.includes(role)) return true;

  const newRoles = [...currentRoles, role];

  const { error } = await supabase
    .from("profiles")
    .update({ role: newRoles })
    .eq("id", userId);

  if (error) {
    console.error("Error assigning role:", error);
    return false;
  }

  return true;
}

export async function revokeRole(userId: string, role: UserRole): Promise<boolean> {
  const { data: profile } = await supabase
    .from("profiles")
    .select("role")
    .eq("id", userId)
    .maybeSingle();

  if (!profile) return false;

  const currentRoles = profile.role || [];
  const newRoles = currentRoles.filter((r: UserRole) => r !== role);

  if (newRoles.length === 0) {
    newRoles.push('customer');
  }

  const { error } = await supabase
    .from("profiles")
    .update({ role: newRoles })
    .eq("id", userId);

  if (error) {
    console.error("Error revoking role:", error);
    return false;
  }

  return true;
}

// Invitation APIs
export async function createInvitation(
  email: string,
  roleToAssign: 'runner' | 'admin',
  inviteeFirstName?: string,
  inviteeLastName?: string,
  notes?: string
): Promise<Invitation | null> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;

  const token = crypto.randomUUID();
  const expiresAt = new Date();
  expiresAt.setDate(expiresAt.getDate() + 7);

  const { data, error } = await supabase
    .from("invitations")
    .insert({
      email,
      invited_by: user.id,
      role_to_assign: roleToAssign,
      token,
      expires_at: expiresAt.toISOString(),
      invitee_first_name: inviteeFirstName,
      invitee_last_name: inviteeLastName,
      notes
    })
    .select()
    .maybeSingle();

  if (error) {
    console.error("Error creating invitation:", error);
    throw error;
  }

  return data;
}

export async function getPendingInvitations(): Promise<InvitationWithDetails[]> {
  const { data, error } = await supabase
    .from("invitations")
    .select(`
      *,
      inviter:invited_by(*)
    `)
    .eq("status", "Pending")
    .order("created_at", { ascending: false });

  if (error) {
    console.error("Error fetching invitations:", error);
    return [];
  }

  return Array.isArray(data) ? data : [];
}

export async function getAllInvitations(): Promise<InvitationWithDetails[]> {
  const { data, error } = await supabase
    .from("invitations")
    .select(`
      *,
      inviter:invited_by(*)
    `)
    .order("created_at", { ascending: false });

  if (error) {
    console.error("Error fetching invitations:", error);
    return [];
  }

  return Array.isArray(data) ? data : [];
}

export async function validateInvitationToken(token: string): Promise<Invitation | null> {
  const { data, error } = await supabase
    .from("invitations")
    .select("*")
    .eq("token", token)
    .eq("is_used", false)
    .eq("status", "Pending")
    .maybeSingle();

  if (error || !data) {
    return null;
  }

  if (new Date(data.expires_at) < new Date()) {
    await supabase
      .from("invitations")
      .update({ status: "Expired" })
      .eq("id", data.id);
    return null;
  }

  return data;
}

export async function acceptInvitation(token: string): Promise<boolean> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return false;

  const invitation = await validateInvitationToken(token);
  if (!invitation) return false;

  const { error: invError } = await supabase
    .from("invitations")
    .update({
      is_used: true,
      used_at: new Date().toISOString(),
      status: "Accepted"
    })
    .eq("id", invitation.id);

  if (invError) {
    console.error("Error accepting invitation:", invError);
    return false;
  }

  const roleToAdd = invitation.role_to_assign as UserRole;
  await assignRole(user.id, roleToAdd);

  await supabase
    .from("profiles")
    .update({
      invited_by: invitation.invited_by,
      invitation_accepted_at: new Date().toISOString()
    })
    .eq("id", user.id);

  return true;
}

export async function revokeInvitation(invitationId: string): Promise<boolean> {
  const { error } = await supabase
    .from("invitations")
    .update({ status: "Revoked" })
    .eq("id", invitationId);

  if (error) {
    console.error("Error revoking invitation:", error);
    return false;
  }

  return true;
}

// Customer Address APIs
export async function getCustomerAddresses(): Promise<CustomerAddress[]> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return [];

  const { data, error } = await supabase
    .from("customer_addresses")
    .select("*")
    .eq("customer_id", user.id)
    .order("is_default", { ascending: false })
    .order("created_at", { ascending: false });

  if (error) {
    console.error("Error fetching addresses:", error);
    return [];
  }

  return Array.isArray(data) ? data : [];
}

export async function getDefaultAddress(): Promise<CustomerAddress | null> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;

  const { data, error } = await supabase
    .from("customer_addresses")
    .select("*")
    .eq("customer_id", user.id)
    .eq("is_default", true)
    .maybeSingle();

  if (error) {
    console.error("Error fetching default address:", error);
    return null;
  }

  return data;
}

export async function getAddressById(addressId: string): Promise<CustomerAddress | null> {
  const { data, error } = await supabase
    .from("customer_addresses")
    .select("*")
    .eq("id", addressId)
    .maybeSingle();

  if (error) {
    console.error("Error fetching address:", error);
    return null;
  }

  return data;
}

export async function createAddress(address: {
  label: string;
  line1: string;
  line2?: string;
  city: string;
  state: string;
  postal_code: string;
  latitude?: number;
  longitude?: number;
  is_default?: boolean;
}): Promise<CustomerAddress | null> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;

  const { data, error } = await supabase
    .from("customer_addresses")
    .insert({
      customer_id: user.id,
      label: address.label,
      line1: address.line1,
      line2: address.line2 || null,
      city: address.city,
      state: address.state,
      postal_code: address.postal_code,
      latitude: address.latitude || null,
      longitude: address.longitude || null,
      is_default: address.is_default || false
    })
    .select()
    .maybeSingle();

  if (error) {
    console.error("Error creating address:", error);
    return null;
  }

  return data;
}

export async function updateAddress(
  addressId: string,
  updates: {
    label?: string;
    line1?: string;
    line2?: string | null;
    city?: string;
    state?: string;
    postal_code?: string;
    latitude?: number | null;
    longitude?: number | null;
    is_default?: boolean;
  }
): Promise<boolean> {
  const { error } = await supabase
    .from("customer_addresses")
    .update(updates)
    .eq("id", addressId);

  if (error) {
    console.error("Error updating address:", error);
    return false;
  }

  return true;
}

export async function deleteAddress(addressId: string): Promise<boolean> {
  const { error } = await supabase
    .from("customer_addresses")
    .delete()
    .eq("id", addressId);

  if (error) {
    console.error("Error deleting address:", error);
    return false;
  }

  return true;
}

export async function setDefaultAddress(addressId: string): Promise<boolean> {
  return await updateAddress(addressId, { is_default: true });
}

export function createAddressSnapshot(address: CustomerAddress): AddressSnapshot {
  return {
    label: address.label,
    line1: address.line1,
    line2: address.line2,
    city: address.city,
    state: address.state,
    postal_code: address.postal_code,
    latitude: address.latitude,
    longitude: address.longitude
  };
}

export function formatAddress(address: CustomerAddress | AddressSnapshot): string {
  const parts = [
    address.line1,
    address.line2,
    `${address.city}, ${address.state} ${address.postal_code}`
  ].filter(Boolean);
  
  return parts.join(", ");
}

// Order APIs
export async function createOrder(
  requestedAmount: number,
  customerAddress: string,
  customerNotes?: string,
  addressId?: string
): Promise<Order | null> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;

  // Fetch customer profile to get their name
  const { data: profile } = await supabase
    .from("profiles")
    .select("first_name, last_name")
    .eq("id", user.id)
    .maybeSingle();

  // Construct customer name from profile, with fallback
  const customerName = profile && (profile.first_name || profile.last_name)
    ? `${profile.first_name || ''} ${profile.last_name || ''}`.trim()
    : 'Customer';

  const fees = calculateFees(requestedAmount);

  // If addressId is provided, fetch the address and create snapshot
  let addressSnapshot: AddressSnapshot | null = null;
  if (addressId) {
    const address = await getAddressById(addressId);
    if (address) {
      addressSnapshot = createAddressSnapshot(address);
    }
  }

  const { data, error } = await supabase
    .from("orders")
    .insert({
      customer_id: user.id,
      requested_amount: fees.requestedAmount,
      profit: fees.profit,
      compliance_fee: fees.complianceFee,
      delivery_fee: fees.deliveryFee,
      total_service_fee: fees.totalServiceFee,
      total_payment: fees.totalPayment,
      address_id: addressId || null,
      address_snapshot: addressSnapshot,
      customer_address: customerAddress, // Legacy field for backward compatibility
      customer_name: customerName,
      customer_notes: customerNotes || null,
      status: "Pending"
    })
    .select()
    .maybeSingle();

  if (error) {
    console.error("Error creating order:", error);
    throw error;
  }

  return data;
}

export async function getCustomerOrders(): Promise<OrderWithDetails[]> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return [];

  const { data, error } = await supabase
    .from("orders")
    .select(`
      *,
      customer:customer_id(*),
      runner:runner_id(*)
    `)
    .eq("customer_id", user.id)
    .order("created_at", { ascending: false });

  if (error) {
    console.error("Error fetching customer orders:", error);
    return [];
  }

  return Array.isArray(data) ? data : [];
}

export async function getRunnerOrders(): Promise<OrderWithDetails[]> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return [];

  const { data, error } = await supabase
    .from("orders")
    .select(`
      *,
      customer:customer_id(*),
      runner:runner_id(*)
    `)
    .eq("runner_id", user.id)
    .order("created_at", { ascending: false });

  if (error) {
    console.error("Error fetching runner orders:", error);
    return [];
  }

  return Array.isArray(data) ? data : [];
}

export async function getAvailableOrders(): Promise<OrderWithDetails[]> {
  const { data, error } = await supabase
    .from("orders")
    .select(`
      *,
      customer:customer_id(*),
      runner:runner_id(*)
    `)
    .eq("status", "Pending")
    .order("created_at", { ascending: false });

  if (error) {
    console.error("Error fetching available orders:", error);
    return [];
  }

  return Array.isArray(data) ? data : [];
}

export async function getAllOrders(): Promise<OrderWithDetails[]> {
  const { data, error } = await supabase
    .from("orders")
    .select(`
      *,
      customer:customer_id(*),
      runner:runner_id(*)
    `)
    .order("created_at", { ascending: false });

  if (error) {
    console.error("Error fetching all orders:", error);
    return [];
  }

  return Array.isArray(data) ? data : [];
}

export async function getOrderById(orderId: string): Promise<OrderWithDetails | null> {
  const { data, error } = await supabase
    .from("orders")
    .select(`
      *,
      customer:customer_id(*),
      runner:runner_id(*)
    `)
    .eq("id", orderId)
    .maybeSingle();

  if (error) {
    console.error("Error fetching order:", error);
    return null;
  }

  return data;
}

export async function acceptOrder(orderId: string): Promise<boolean> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      console.error("Accept order failed: No authenticated user");
      return false;
    }

    // First, fetch the current order to verify it exists and is in Pending status
    const { data: existingOrder, error: fetchError } = await supabase
      .from("orders")
      .select("*")
      .eq("id", orderId)
      .maybeSingle();

    if (fetchError) {
      console.error("Error fetching order:", fetchError);
      return false;
    }

    if (!existingOrder) {
      console.error("Order not found:", orderId);
      return false;
    }

    if (existingOrder.status !== "Pending") {
      console.error("Order is not in Pending status. Current status:", existingOrder.status);
      return false;
    }

    // Update the order status to "Runner Accepted"
    const { data: updatedOrder, error: updateError } = await supabase
      .from("orders")
      .update({
        runner_id: user.id,
        status: "Runner Accepted",
        runner_accepted_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      })
      .eq("id", orderId)
      .eq("status", "Pending")
      .select()
      .maybeSingle();

    if (updateError) {
      console.error("Error updating order status:", updateError);
      return false;
    }

    if (!updatedOrder) {
      console.error("Order update returned no data. Order may have been accepted by another runner.");
      return false;
    }

    // Create audit log entry
    await createAuditLog(
      "ACCEPT_ORDER",
      "order",
      orderId,
      { status: "Pending", runner_id: null },
      { 
        status: "Runner Accepted", 
        runner_id: user.id,
        runner_accepted_at: updatedOrder.runner_accepted_at
      }
    );

    console.log("Order accepted successfully:", {
      orderId,
      runnerId: user.id,
      newStatus: updatedOrder.status,
      timestamp: updatedOrder.runner_accepted_at
    });

    return true;
  } catch (error) {
    console.error("Unexpected error in acceptOrder:", error);
    return false;
  }
}

// Note: updateOrderStatus has been moved to FSM section below (line ~864)
// It now uses advanceOrderStatus for proper FSM validation

export async function generateOTP(orderId: string): Promise<string | null> {
  const otp = Math.floor(100000 + Math.random() * 900000).toString();
  const expiresAt = new Date();
  expiresAt.setMinutes(expiresAt.getMinutes() + 10);

  const { error } = await supabase
    .from("orders")
    .update({
      otp_code: otp,
      otp_expires_at: expiresAt.toISOString(),
      otp_attempts: 0,
      status: "Pending Handoff"
    })
    .eq("id", orderId);

  if (error) {
    console.error("Error generating OTP:", error);
    return null;
  }

  return otp;
}

export async function verifyOTP(orderId: string, otp: string): Promise<boolean> {
  const { data: order } = await supabase
    .from("orders")
    .select("otp_code, otp_expires_at, otp_attempts")
    .eq("id", orderId)
    .maybeSingle();

  if (!order || !order.otp_code || !order.otp_expires_at) {
    return false;
  }

  if (new Date(order.otp_expires_at) < new Date()) {
    return false;
  }

  if (order.otp_attempts >= 3) {
    return false;
  }

  if (order.otp_code !== otp) {
    await supabase
      .from("orders")
      .update({ otp_attempts: order.otp_attempts + 1 })
      .eq("id", orderId);
    return false;
  }

  await updateOrderStatus(orderId, "Completed");
  return true;
}

// Admin: Cancel an order (uses FSM to handle any valid status)
export async function cancelOrder(orderId: string, reason: string): Promise<{ success: boolean; message: string }> {
  try {
    // Get current user
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      return { success: false, message: "Not authenticated" };
    }

    // Verify user is admin
    const profile = await getCurrentProfile();
    if (!profile || !profile.role.includes('admin')) {
      return { success: false, message: "Unauthorized: Admin access required" };
    }

    // Get the order to verify it exists
    const { data: order, error: fetchError } = await supabase
      .from("orders")
      .select("*")
      .eq("id", orderId)
      .maybeSingle();

    if (fetchError) {
      console.error("Error fetching order:", fetchError);
      return { success: false, message: "Failed to fetch order" };
    }

    if (!order) {
      return { success: false, message: "Order not found" };
    }

    // Check if order is already cancelled or completed
    // Admins can cancel from any status except Completed
    if (order.status === 'Cancelled') {
      return { success: false, message: "Order is already cancelled" };
    }

    if (order.status === 'Completed') {
      return { success: false, message: "Cannot cancel a completed order" };
    }

    // Admin can cancel from any other status (Pending, Runner Accepted, Runner at ATM, Cash Withdrawn, Pending Handoff)
    // This is handled by the FSM function which allows admin to bypass transition table checks

    // Use FSM to cancel the order (this handles state transitions properly)
    const { error: fsmError } = await supabase.rpc('rpc_advance_order', {
      p_order_id: orderId,
      p_next_status: 'Cancelled',
      p_metadata: {
        reason: reason,
        cancelled_by: user.id
      }
    });

    if (fsmError) {
      console.error("Error cancelling order via FSM:", fsmError);
      console.error("FSM Error details:", JSON.stringify(fsmError, null, 2));
      console.error("Order status:", order.status);
      console.error("User role:", profile.role);
      return { 
        success: false, 
        message: fsmError.message || `Failed to cancel order: ${JSON.stringify(fsmError)}` 
      };
    }

    // Create audit log entry
    await createAuditLog(
      "CANCEL_ORDER",
      "order",
      orderId,
      { status: order.status },
      { 
        status: 'Cancelled', 
        cancelled_by: user.id, 
        cancellation_reason: reason,
        cancelled_at: new Date().toISOString()
      }
    );

    return { success: true, message: "Order cancelled successfully" };
  } catch (error: any) {
    console.error("Error in cancelOrder:", error);
    return { success: false, message: error.message || "An unexpected error occurred" };
  }
}

export async function updateRunnerOnlineStatus(isOnline: boolean): Promise<{ success: boolean; error?: string; data?: any }> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      return { success: false, error: "Not authenticated" };
    }

    // Verify user is a runner
    const profile = await getCurrentProfile();
    if (!profile || !profile.role.includes('runner')) {
      return { success: false, error: "Unauthorized: Runner access required" };
    }

    // Update is_online status
    const { data, error } = await supabase
      .from("profiles")
      .update({ is_online: isOnline })
      .eq("id", user.id)
      .select("is_online")
      .single();

    if (error) {
      // Check if it's a column missing error
      const errorMessage = error.message || '';
      if (errorMessage.includes("is_online") || errorMessage.includes("schema cache")) {
        // In dev: log warning and no-op gracefully
        if (import.meta.env.DEV) {
          console.warn(
            "[updateRunnerOnlineStatus] is_online column not found. " +
            "This feature requires a database migration. " +
            "See ADD_IS_ONLINE_COLUMN.sql or FIX_RUNNER_ONLINE_TOGGLE.md for instructions."
          );
          // Return success to prevent UI errors, but log the issue
          return { success: true, error: undefined, data: { is_online: false } };
        }
        return { 
          success: false, 
          error: "Database configuration issue. The is_online column is missing. Please contact support." 
        };
      }
      return { success: false, error: error.message || "Failed to update online status" };
    }

    return { success: true, data };
  } catch (error: any) {
    console.error("Error in updateRunnerOnlineStatus:", error);
    const errorMessage = error?.message || "An unexpected error occurred";
    
    // Handle missing column gracefully in dev
    if (import.meta.env.DEV && (errorMessage.includes("is_online") || errorMessage.includes("schema cache"))) {
      console.warn("[updateRunnerOnlineStatus] Column missing - no-op in dev mode");
      return { success: true, error: undefined, data: { is_online: false } };
    }
    
    return { success: false, error: errorMessage };
  }
}

export async function getRunnerEarningsStats(): Promise<{
  monthlyEarnings: number;
  activeDeliveries: number;
  completedThisMonth: number;
}> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) {
    return { monthlyEarnings: 0, activeDeliveries: 0, completedThisMonth: 0 };
  }

  // Get all runner orders
  const { data: orders, error } = await supabase
    .from("orders")
    .select("*")
    .eq("runner_id", user.id)
    .order("created_at", { ascending: false });

  if (error) {
    console.error("Error fetching runner orders for earnings:", error);
    return { monthlyEarnings: 0, activeDeliveries: 0, completedThisMonth: 0 };
  }

  if (!orders || orders.length === 0) {
    return { monthlyEarnings: 0, activeDeliveries: 0, completedThisMonth: 0 };
  }

  const now = new Date();
  const currentMonth = now.getMonth();
  const currentYear = now.getFullYear();

  // Active deliveries (in-progress statuses)
  const activeStatuses = ['Runner Accepted', 'Runner at ATM', 'Cash Withdrawn', 'Pending Handoff'];
  const activeDeliveries = orders.filter(o => 
    activeStatuses.includes(o.status)
  ).length;

  // Completed orders this month
  const completedThisMonth = orders.filter(o => {
    if (o.status !== 'Completed') return false;
    
    const completedDate = o.handoff_completed_at 
      ? new Date(o.handoff_completed_at)
      : new Date(o.updated_at);
    
    return (
      completedDate.getMonth() === currentMonth &&
      completedDate.getFullYear() === currentYear
    );
  });

  // Calculate monthly earnings from completed orders
  const monthlyEarnings = completedThisMonth.reduce((total, order) => {
    return total + (order.delivery_fee || 0);
  }, 0);

  return {
    monthlyEarnings,
    activeDeliveries,
    completedThisMonth: completedThisMonth.length,
  };
}

export async function getRunnerStatsForAdmin(runnerId: string): Promise<{
  activeDeliveries: number;
  completedThisMonth: number;
  monthlyEarnings: number;
  totalCompleted: number;
  totalEarnings: number;
}> {
  const { data: orders, error } = await supabase
    .from("orders")
    .select("*")
    .eq("runner_id", runnerId)
    .order("created_at", { ascending: false });

  if (error) {
    console.error("Error fetching runner orders for admin:", error);
    return {
      activeDeliveries: 0,
      completedThisMonth: 0,
      monthlyEarnings: 0,
      totalCompleted: 0,
      totalEarnings: 0,
    };
  }

  if (!orders || orders.length === 0) {
    return {
      activeDeliveries: 0,
      completedThisMonth: 0,
      monthlyEarnings: 0,
      totalCompleted: 0,
      totalEarnings: 0,
    };
  }

  const now = new Date();
  const currentMonth = now.getMonth();
  const currentYear = now.getFullYear();

  // Active deliveries (in-progress statuses)
  const activeStatuses = ['Runner Accepted', 'Runner at ATM', 'Cash Withdrawn', 'Pending Handoff'];
  const activeDeliveries = orders.filter(o => activeStatuses.includes(o.status)).length;

  // Completed orders
  const completedOrders = orders.filter(o => o.status === 'Completed');
  const totalCompleted = completedOrders.length;

  // Completed this month
  const completedThisMonth = completedOrders.filter(o => {
    const completedDate = o.handoff_completed_at 
      ? new Date(o.handoff_completed_at)
      : new Date(o.updated_at);
    return (
      completedDate.getMonth() === currentMonth &&
      completedDate.getFullYear() === currentYear
    );
  });

  // Calculate earnings
  const monthlyEarnings = completedThisMonth.reduce((total, order) => {
    return total + (order.delivery_fee || 0);
  }, 0);

  const totalEarnings = completedOrders.reduce((total, order) => {
    return total + (order.delivery_fee || 0);
  }, 0);

  return {
    activeDeliveries,
    completedThisMonth: completedThisMonth.length,
    monthlyEarnings,
    totalCompleted,
    totalEarnings,
  };
}

export async function getCustomerStatsForAdmin(customerId: string): Promise<{
  activeOrders: number;
  totalOrders: number;
  completedOrders: number;
  totalSpent: number;
}> {
  const { data: orders, error } = await supabase
    .from("orders")
    .select("*")
    .eq("customer_id", customerId)
    .order("created_at", { ascending: false });

  if (error) {
    console.error("Error fetching customer orders for admin:", error);
    return {
      activeOrders: 0,
      totalOrders: 0,
      completedOrders: 0,
      totalSpent: 0,
    };
  }

  if (!orders || orders.length === 0) {
    return {
      activeOrders: 0,
      totalOrders: 0,
      completedOrders: 0,
      totalSpent: 0,
    };
  }

  // Active orders (non-final statuses)
  const finalStatuses = ['Completed', 'Cancelled'];
  const activeOrders = orders.filter(o => !finalStatuses.includes(o.status)).length;

  // Completed orders
  const completedOrders = orders.filter(o => o.status === 'Completed').length;

  // Total spent (from completed orders)
  const totalSpent = orders
    .filter(o => o.status === 'Completed')
    .reduce((total, order) => total + (order.requested_amount || 0), 0);

  return {
    activeOrders,
    totalOrders: orders.length,
    completedOrders,
    totalSpent,
  };
}

export async function syncAuthUsersToProfiles(): Promise<{ success: boolean; message: string; synced: number }> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      return { success: false, message: "Not authenticated", synced: 0 };
    }

    const profile = await getCurrentProfile();
    if (!profile || !profile.role.includes('admin')) {
      return { success: false, message: "Unauthorized: Admin access required", synced: 0 };
    }

    // Call the database function to sync auth users to profiles
    const { data, error } = await supabase.rpc('sync_auth_users_to_profiles');

    if (error) {
      console.error("Error syncing auth users to profiles:", error);
      return { success: false, message: error.message, synced: 0 };
    }

    return { success: true, message: "Users synced successfully", synced: data || 0 };
  } catch (error: any) {
    console.error("Error in syncAuthUsersToProfiles:", error);
    return { success: false, message: error.message || "An unexpected error occurred", synced: 0 };
  }
}

// Admin: Cancel all live orders (bulk cancellation)
export async function cancelAllLiveOrders(): Promise<{ success: boolean; cancelled: number; failed: number; errors: string[] }> {
  try {
    // Get current user
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      return { success: false, cancelled: 0, failed: 0, errors: ["Not authenticated"] };
    }

    // Verify user is admin
    const profile = await getCurrentProfile();
    if (!profile || !profile.role.includes('admin')) {
      return { success: false, cancelled: 0, failed: 0, errors: ["Unauthorized: Admin access required"] };
    }

    // Get all live orders (not completed, not cancelled)
    const { data: orders, error: fetchError } = await supabase
      .from("orders")
      .select("id, status")
      .not('status', 'in', '(Completed,Cancelled)');

    if (fetchError) {
      console.error("Error fetching orders:", fetchError);
      return { success: false, cancelled: 0, failed: 0, errors: [fetchError.message] };
    }

    if (!orders || orders.length === 0) {
      return { success: true, cancelled: 0, failed: 0, errors: [] };
    }

    let cancelled = 0;
    let failed = 0;
    const errors: string[] = [];

    // Cancel each order using FSM
    for (const order of orders) {
      try {
        const { error: fsmError } = await supabase.rpc('rpc_advance_order', {
          p_order_id: order.id,
          p_next_status: 'Cancelled',
          p_metadata: {
            reason: 'Bulk cancellation by admin',
            cancelled_by: user.id,
            bulk_cancellation: true
          }
        });

        if (fsmError) {
          failed++;
          errors.push(`${order.id.slice(0, 8)}: ${fsmError.message}`);
        } else {
          cancelled++;
        }
      } catch (error: any) {
        failed++;
        errors.push(`${order.id.slice(0, 8)}: ${error.message}`);
      }
    }

    return { success: true, cancelled, failed, errors };
  } catch (error: any) {
    console.error("Error in cancelAllLiveOrders:", error);
    return { success: false, cancelled: 0, failed: 0, errors: [error.message] };
  }
}

// Audit Log APIs
export async function createAuditLog(
  action: string,
  entityType: string,
  entityId: string,
  oldValues?: Record<string, unknown>,
  newValues?: Record<string, unknown>
): Promise<void> {
  const { data: { user } } = await supabase.auth.getUser();

  await supabase
    .from("audit_logs")
    .insert({
      user_id: user?.id || null,
      action,
      entity_type: entityType,
      entity_id: entityId,
      old_values: oldValues || null,
      new_values: newValues || null
    });
}

export async function getAuditLogs(limit = 100): Promise<any[]> {
  const { data, error } = await supabase
    .from("audit_logs")
    .select("*")
    .order("created_at", { ascending: false })
    .limit(limit);

  if (error) {
    console.error("Error fetching audit logs:", error);
    return [];
  }

  return Array.isArray(data) ? data : [];
}

// ============================================================================
// Finite State Machine (FSM) Functions
// ============================================================================

/**
 * Advance order status using FSM with validation and audit trail
 * This is the ONLY way to change order status - prevents illegal transitions
 * 
 * @param orderId - Order ID to update
 * @param nextStatus - Target status
 * @param clientActionId - Idempotency key (optional but recommended)
 * @param metadata - Additional data to store in audit trail
 * @returns Updated order or null if failed
 */
export async function advanceOrderStatus(
  orderId: string,
  nextStatus: OrderStatus,
  clientActionId?: string,
  metadata?: Record<string, any>
): Promise<Order | null> {
  try {
    // Generate idempotency key if not provided
    const actionId = clientActionId || crypto.randomUUID();
    
    const { data, error } = await supabase.rpc('rpc_advance_order', {
      p_order_id: orderId,
      p_next_status: nextStatus,
      p_client_action_id: actionId,
      p_metadata: metadata || {}
    });

    if (error) {
      console.error('Error advancing order status:', error);
      throw new Error(error.message);
    }

    return data;
  } catch (error) {
    console.error('Failed to advance order status:', error);
    throw error;
  }
}

/**
 * Get complete audit trail for an order
 * Shows all status transitions with actor information
 * 
 * @param orderId - Order ID
 * @returns Array of order events with details
 */
export async function getOrderHistory(orderId: string): Promise<OrderEventWithDetails[]> {
  try {
    const { data, error } = await supabase.rpc('rpc_get_order_history', {
      p_order_id: orderId
    });

    if (error) {
      console.error('Error fetching order history:', error);
      return [];
    }

    return Array.isArray(data) ? data : [];
  } catch (error) {
    console.error('Failed to fetch order history:', error);
    return [];
  }
}

/**
 * Check if a status transition is valid
 * Useful for UI to show/hide action buttons
 * 
 * @param fromStatus - Current status
 * @param toStatus - Target status
 * @returns True if transition is allowed
 */
export async function isValidTransition(
  fromStatus: OrderStatus,
  toStatus: OrderStatus
): Promise<boolean> {
  try {
    const { data, error } = await supabase.rpc('is_valid_transition', {
      p_from_status: fromStatus,
      p_to_status: toStatus
    });

    if (error) {
      console.error('Error checking transition validity:', error);
      return false;
    }

    return data === true;
  } catch (error) {
    console.error('Failed to check transition validity:', error);
    return false;
  }
}

/**
 * Get all valid next statuses for current order status
 * Useful for showing available actions in UI
 * 
 * @param currentStatus - Current order status
 * @returns Array of valid next statuses
 */
export async function getValidNextStatuses(currentStatus: OrderStatus): Promise<OrderStatus[]> {
  try {
    const { data, error } = await supabase
      .from('order_status_transitions')
      .select('to_status')
      .eq('from_status', currentStatus);

    if (error) {
      console.error('Error fetching valid next statuses:', error);
      return [];
    }

    return Array.isArray(data) ? data.map(row => row.to_status) : [];
  } catch (error) {
    console.error('Failed to fetch valid next statuses:', error);
    return [];
  }
}

// ============================================================================
// Legacy function - DEPRECATED - Use advanceOrderStatus instead
// ============================================================================

/**
 * @deprecated Use advanceOrderStatus instead for FSM validation
 * This function bypasses FSM validation and should not be used
 */
export async function updateOrderStatus(
  orderId: string,
  status: OrderStatus,
  additionalData?: Partial<Order>
): Promise<boolean> {
  console.warn('⚠️ updateOrderStatus is deprecated. Use advanceOrderStatus instead for FSM validation.');
  
  // For backward compatibility, call the new FSM function
  try {
    const metadata = additionalData ? { legacy_data: additionalData } : {};
    const result = await advanceOrderStatus(orderId, status, undefined, metadata);
    return result !== null;
  } catch (error) {
    console.error('Error in legacy updateOrderStatus:', error);
    return false;
  }
}

// Real-time subscriptions
// Realtime Subscriptions
export function subscribeToOrders(callback: (payload: any) => void) {
  const channel = supabase
    .channel("orders")
    .on("postgres_changes", { event: "*", schema: "public", table: "orders" }, (payload) => {
      console.log("[Realtime] Orders change detected:", payload.eventType, payload.new || payload.old);
      callback(payload);
    })
    .subscribe((status) => {
      console.log("[Realtime] Orders subscription status:", status);
      if (status === "CHANNEL_ERROR" || status === "TIMED_OUT") {
        console.error("[Realtime] Orders subscription failed:", status);
      }
    });

  return channel;
}

export function subscribeToOrder(orderId: string, callback: (payload: any) => void) {
  const channel = supabase
    .channel(`order:${orderId}`)
    .on("postgres_changes", { event: "*", schema: "public", table: "orders", filter: `id=eq.${orderId}` }, (payload) => {
      console.log(`[Realtime] Order ${orderId} change detected:`, payload.eventType, payload.new || payload.old);
      callback(payload);
    })
    .subscribe((status) => {
      console.log(`[Realtime] Order ${orderId} subscription status:`, status);
      if (status === "CHANNEL_ERROR" || status === "TIMED_OUT") {
        console.error(`[Realtime] Order ${orderId} subscription failed:`, status);
      }
    });

  return channel;
}

// Admin: Create a test/mock order for runner training
export async function createTestOrder(): Promise<{ success: boolean; orderId?: string; message: string }> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      return { success: false, message: "Not authenticated" };
    }

    // Verify user is admin
    const profile = await getCurrentProfile();
    if (!profile || !profile.role.includes('admin')) {
      return { success: false, message: "Unauthorized: Admin access required" };
    }

    // Calculate fees for $100 test order
    const fees = calculateFees(100);

    // Create a test order with mock data
    const testOrderData = {
      customer_id: user.id, // Use admin as customer for test
      requested_amount: fees.requestedAmount,
      profit: fees.profit,
      compliance_fee: fees.complianceFee,
      delivery_fee: fees.deliveryFee,
      total_service_fee: fees.totalServiceFee,
      total_payment: fees.totalPayment,
      customer_address: "ABC Bank ATM, 123 XYZ Street",
      customer_name: "Test Customer",
      customer_notes: "🎓 TRAINING ORDER: This is a test order. Use this to familiarize yourself with the acceptance and completion process. Delivery location: Central Office, 456 Main Avenue.",
      status: "Pending" as const
    };

    const { data, error } = await supabase
      .from("orders")
      .insert(testOrderData)
      .select()
      .maybeSingle();

    if (error) {
      console.error("Error creating test order:", error);
      return { success: false, message: "Failed to create test order" };
    }

    if (!data) {
      return { success: false, message: "No data returned after creating test order" };
    }

    // Create audit log entry
    await createAuditLog(
      "CREATE_TEST_ORDER",
      "order",
      data.id,
      {},
      testOrderData
    );

    return { 
      success: true, 
      orderId: data.id,
      message: "Test order created successfully" 
    };
  } catch (error) {
    console.error("Error in createTestOrder:", error);
    return { success: false, message: "An unexpected error occurred" };
  }
}
