/**
 * CustomerLayout Component
 * 
 * Wrapper layout for customer pages that includes:
 * - CustomerHeader (light theme)
 * - PageContainer with customer theme
 * - Fixed bottom navigation with Request Cash CTA (hidden in request flow)
 * - Proper padding to avoid content being hidden
 */

import { PageContainer } from './PageContainer';
import { CustomerBottomNav } from './CustomerBottomNav';
import { CustomerHeader } from './CustomerHeader';

interface CustomerLayoutProps {
  children: React.ReactNode;
}

export function CustomerLayout({ children }: CustomerLayoutProps) {
  return (
    <div className="h-full flex flex-col bg-[#F5F5F7] overflow-hidden">
      <CustomerHeader />
      <PageContainer variant="customer">
        <main className="flex-1 overflow-y-auto pb-28">
          {children}
        </main>
      </PageContainer>

      {/* Fixed bottom navigation - hidden in request flow */}
      <CustomerBottomNav />
    </div>
  );
}
