import { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { DollarSign, Menu, User, LogOut, Truck, Package, Home, Radio } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";
import { useProfile } from "@/contexts/ProfileContext";
import { updateRunnerOnlineStatus } from "@/db/api";
import { toast } from "sonner";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";

export function RunnerHeader() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [showLogoutDialog, setShowLogoutDialog] = useState(false);
  const [updatingOnlineStatus, setUpdatingOnlineStatus] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const { profile, refreshProfile } = useProfile();

  const handleLogoutClick = () => {
    setShowLogoutDialog(true);
    setIsMenuOpen(false);
  };

  const confirmLogout = async () => {
    await logout();
    setShowLogoutDialog(false);
    navigate("/");
  };

  const handleMenuItemClick = (path: string) => {
    navigate(path);
    setIsMenuOpen(false);
  };

  const handleOnlineToggle = async (checked: boolean) => {
    // Optimistic update - update UI immediately
    const previousStatus = profile?.is_online;
    if (profile) {
      // Temporarily update local state for instant feedback
      // The refreshProfile() call will sync with server
    }
    
    setUpdatingOnlineStatus(true);
    try {
      const result = await updateRunnerOnlineStatus(checked);
      if (result.success) {
        // Refresh profile to get latest data from server
        await refreshProfile();
        toast.success(checked ? "You're now online" : "You're now offline");
      } else {
        // Rollback optimistic update by refreshing profile
        await refreshProfile();
        const errorMessage = result.error || "Failed to update status";
        console.error("Error updating online status:", errorMessage);
        
        // In dev: show friendly message for missing column
        if (import.meta.env.DEV && (errorMessage.includes("is_online") || errorMessage.includes("schema cache"))) {
          toast.error("Online status feature requires database migration. See console for details.");
        } else {
          toast.error(errorMessage);
        }
      }
    } catch (error: any) {
      // Rollback optimistic update
      await refreshProfile();
      console.error("Error updating online status:", error);
      let errorMessage = "Failed to update status";
      if (error?.message?.includes("is_online") || error?.message?.includes("schema cache")) {
        errorMessage = import.meta.env.DEV 
          ? "Database migration required. See console for details."
          : "Database configuration issue. Please contact support.";
      } else if (error?.message) {
        errorMessage = error.message;
      }
      toast.error(errorMessage);
    } finally {
      setUpdatingOnlineStatus(false);
    }
  };

  const isActive = (path: string, exact: boolean = false) => {
    if (exact) {
      return location.pathname === path;
    }
    return location.pathname.startsWith(path);
  };

  const getMenuItemClasses = (path: string, exact: boolean = false, isDestructive: boolean = false) => {
    const baseClasses = "w-full flex items-center gap-3 px-3 py-3 text-sm font-medium rounded-md transition-colors text-left relative";
    const active = isActive(path, exact);
    
    if (isDestructive) {
      return `${baseClasses} ${active ? 'bg-destructive/10 text-destructive border-l-2 border-destructive' : 'text-destructive hover:bg-destructive/10 hover:text-destructive'}`;
    }
    
    if (active) {
      return `${baseClasses} bg-indigo-500/20 text-white font-semibold border-l-2 border-indigo-400`;
    }
    
    return `${baseClasses} hover:bg-slate-800 hover:text-white text-slate-300`;
  };

  const isRunner = profile?.role.includes('runner');

  return (
    <header className="bg-[#020817] border-b border-slate-800 sticky top-0 z-50">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          {/* Logo */}
          <div className="flex items-center">
            <Link to="/runner/home" className="flex items-center gap-2">
              <div className="bg-indigo-600 text-white rounded-lg p-2">
                <DollarSign className="h-6 w-6" />
              </div>
              <span className="text-xl font-bold text-white">Benjamin</span>
            </Link>
          </div>

          {/* Online Status Toggle + Menu */}
          <div className="flex items-center gap-4">
            {/* Online/Offline Toggle */}
            {isRunner && (
              <div
                className={cn(
                  "flex items-center gap-2 px-3 py-1.5 rounded-lg border transition-colors",
                  profile?.is_online
                    ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/40"
                    : "bg-slate-800 text-slate-400 border-slate-600"
                )}
              >
                <Radio className={`h-4 w-4 ${profile?.is_online ? 'text-emerald-400' : 'text-slate-500'}`} />
                <Label htmlFor="online-toggle" className="text-sm font-medium cursor-pointer">
                  {profile?.is_online ? 'Online' : 'Offline'}
                </Label>
                <Switch
                  id="online-toggle"
                  checked={profile?.is_online ?? false}
                  onCheckedChange={handleOnlineToggle}
                  disabled={updatingOnlineStatus}
                  className="data-[state=checked]:bg-emerald-500"
                />
              </div>
            )}

            {/* Hamburger Menu */}
            <Sheet open={isMenuOpen} onOpenChange={setIsMenuOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="sm" className="gap-2 text-white hover:bg-slate-800">
                  <Menu className="h-5 w-5" />
                  <span className="sr-only">Open menu</span>
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-80 bg-[#020817] border-slate-800">
                <SheetHeader>
                  <SheetTitle className="text-white">Menu</SheetTitle>
                  <SheetDescription className="text-slate-400">
                    {user ? (
                      <div className="text-left">
                        {profile ? (
                          <>
                            <p className="font-semibold text-white">{profile.first_name} {profile.last_name}</p>
                            <p className="text-sm text-slate-400">{user.email}</p>
                            <div className="flex gap-2 mt-2 flex-wrap">
                              {profile.role.map((role) => (
                                <Badge key={role} variant="secondary" className="text-xs bg-indigo-500/20 text-indigo-300">
                                  {role}
                                </Badge>
                              ))}
                            </div>
                          </>
                        ) : (
                          <>
                            <p className="font-semibold text-white">Loading profile...</p>
                            <p className="text-sm text-slate-400">{user.email}</p>
                          </>
                        )}
                      </div>
                    ) : (
                      "Access your account"
                    )}
                  </SheetDescription>
                </SheetHeader>

                <div className="mt-6 space-y-1">
                  {user ? (
                    <>
                      {/* Profile Link */}
                      <button
                        onClick={() => handleMenuItemClick("/account")}
                        className={getMenuItemClasses("/account", true)}
                      >
                        <User className="h-5 w-5" />
                        <span>My Profile</span>
                      </button>

                      <Separator className="my-2 bg-slate-800" />

                      {/* Runner Navigation */}
                      {isRunner && (
                        <>
                          <div className="px-3 py-2 text-xs font-semibold text-slate-500 uppercase tracking-wider">
                            Runner
                          </div>
                          <button
                            onClick={() => handleMenuItemClick("/runner/home")}
                            className={getMenuItemClasses("/runner/home", true)}
                          >
                            <Home className="h-5 w-5" />
                            <span>Home</span>
                          </button>
                          <button
                            onClick={() => handleMenuItemClick("/runner/orders")}
                            className={getMenuItemClasses("/runner/orders", false)}
                          >
                            <Truck className="h-5 w-5" />
                            <span>My Deliveries</span>
                          </button>
                        </>
                      )}

                      <Separator className="my-2 bg-slate-800" />

                      {/* Logout Button */}
                      <button
                        onClick={handleLogoutClick}
                        className={getMenuItemClasses("", false, true)}
                      >
                        <LogOut className="h-5 w-5" />
                        <span>Log Out</span>
                      </button>
                    </>
                  ) : (
                    <>
                      <button
                        onClick={() => handleMenuItemClick("/")}
                        className={getMenuItemClasses("/", true)}
                      >
                        <Home className="h-5 w-5" />
                        <span>Home</span>
                      </button>
                      <button
                        onClick={() => handleMenuItemClick("/login")}
                        className={getMenuItemClasses("/login", true)}
                      >
                        <User className="h-5 w-5" />
                        <span>Log In</span>
                      </button>
                    </>
                  )}
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </nav>
      <AlertDialog open={showLogoutDialog} onOpenChange={setShowLogoutDialog}>
        <AlertDialogContent className="bg-[#020817] border-slate-800">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-white">Confirm Logout</AlertDialogTitle>
            <AlertDialogDescription className="text-slate-400">
              Are you sure you want to log out? You'll need to log in again to access your account.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-slate-800 text-slate-300 border-slate-700">Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmLogout} className="bg-indigo-600 hover:bg-indigo-700">
              Log Out
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </header>
  );
}

