/**
 * RunnerLayout Component
 * 
 * Wrapper layout for runner pages that includes:
 * - RunnerHeader (dark theme with online/offline toggle)
 * - PageContainer with runner dark theme
 * - Consistent dark mode styling
 */

import { PageContainer } from './PageContainer';
import { RunnerHeader } from './RunnerHeader';

interface RunnerLayoutProps {
  children: React.ReactNode;
}

export function RunnerLayout({ children }: RunnerLayoutProps) {
  return (
    <div className="h-full flex flex-col bg-[#020817] overflow-hidden">
      <RunnerHeader />
      <PageContainer variant="runner">
        <main className="flex-1 overflow-y-auto">
          {children}
        </main>
      </PageContainer>
    </div>
  );
}
