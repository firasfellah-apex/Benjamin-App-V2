/**
 * CustomerBottomNav Component
 * 
 * Fixed bottom navigation for customer app with single primary CTA.
 * Features:
 * - Single full-width "Request Cash" button
 * - Fixed positioning with safe-area-aware container
 * - Only renders on customer routes (NOT in request flow)
 * - Hidden when customer has an active order
 */

import { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useProfile } from '@/contexts/ProfileContext';
import { supabase } from '@/db/supabase';

export function CustomerBottomNav() {
  const location = useLocation();
  const navigate = useNavigate();
  const { profile } = useProfile();
  const [hasActiveOrder, setHasActiveOrder] = useState(false);
  const [loading, setLoading] = useState(true);

  // Check for active orders
  useEffect(() => {
    if (!profile) {
      setLoading(false);
      return;
    }

    const checkActiveOrders = async () => {
      try {
        const { data, error } = await supabase
          .from('orders')
          .select('id, status')
          .eq('customer_id', profile.id)
          .in('status', ['Pending', 'Runner Accepted', 'Runner at ATM', 'Cash Withdrawn', 'Pending Handoff'])
          .limit(1);

        if (error) throw error;

        setHasActiveOrder((data?.length || 0) > 0);
      } catch (error) {
        console.error('Error checking active orders:', error);
        setHasActiveOrder(false);
      } finally {
        setLoading(false);
      }
    };

    checkActiveOrders();

    // Subscribe to order changes
    const subscription = supabase
      .channel('customer-orders')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'orders',
          filter: `customer_id=eq.${profile.id}`,
        },
        () => {
          checkActiveOrders();
        }
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, [profile]);

  // Only show on home route
  const isHomeRoute = location.pathname === '/customer' || location.pathname === '/customer/home';
  if (!isHomeRoute) {
    return null;
  }

  // Hide on request flow routes
  if (location.pathname.startsWith('/customer/request')) {
    return null;
  }

  // Hide on tracking routes
  if (location.pathname.startsWith('/customer/orders/')) {
    return null;
  }

  // Hide if there's an active order or still loading
  if (loading || hasActiveOrder) {
    return null;
  }

  return (
    <div
      className="
        fixed inset-x-0 bottom-0 z-40
        bg-white/95 backdrop-blur-md
        border-t border-neutral-200
        px-4 pb-[max(env(safe-area-inset-bottom),16px)] pt-3
        shadow-[0_-6px_18px_rgba(0,0,0,0.06)]
      "
    >
      <button
        onClick={() => navigate('/customer/request')}
        className="
          w-full h-14
          rounded-2xl
          bg-black text-white
          text-[15px] font-semibold
          tracking-tight
          flex items-center justify-center
          transition-transform
          active:scale-[0.98]
        "
      >
        Request Cash
      </button>
    </div>
  );
}

