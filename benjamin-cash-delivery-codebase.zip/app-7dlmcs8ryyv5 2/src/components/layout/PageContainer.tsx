/**
 * PageContainer Component
 * 
 * Unified layout wrapper for customer, runner, and admin apps.
 * Applies theme-specific background and spacing.
 * 
 * Usage:
 * - Customer pages: <PageContainer variant="customer">...</PageContainer>
 * - Runner pages: <PageContainer variant="runner">...</PageContainer>
 * - Admin pages: <PageContainer variant="admin">...</PageContainer>
 */

import { cn } from "@/lib/utils";

export type PageVariant = 'customer' | 'runner' | 'admin';

interface PageContainerProps {
  variant?: PageVariant;
  children: React.ReactNode;
  className?: string;
}

export function PageContainer({
  variant = 'customer',
  children,
  className
}: PageContainerProps) {
  // Theme-specific styles
  const variantStyles = {
    customer: "app-customer bg-[#F5F5F7] text-[#111827]",
    runner: "app-runner bg-[#020817] text-[#E5E7EB]",
    admin: "app-admin bg-[#1B1D21] text-[#F1F3F5]", // Graphite Neutral
  };

  return (
    <div
      className={cn(
        "h-full w-full flex flex-col flex-1 min-h-0",
        variantStyles[variant],
        className
      )}
    >
      <div className="container max-w-4xl mx-auto py-8 px-4 flex-1 min-h-0">
        {children}
      </div>
    </div>
  );
}
