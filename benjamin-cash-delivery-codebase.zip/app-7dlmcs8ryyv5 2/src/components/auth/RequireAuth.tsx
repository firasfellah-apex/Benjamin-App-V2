import { ReactNode } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';

interface RequireAuthProps {
  children: ReactNode;
  whitelist?: string[];
}

export const RequireAuth = ({ children, whitelist = [] }: RequireAuthProps) => {
  const { user, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return <div className="flex items-center justify-center h-screen text-sm text-slate-500">Loading...</div>;
  }

  // Check if current path is whitelisted
  const isWhitelisted = whitelist.some(path => location.pathname === path || location.pathname.startsWith(path));

  // If whitelisted or authenticated, render children
  if (isWhitelisted || user) {
    return <>{children}</>;
  }

  // Not authenticated and not whitelisted - redirect to landing page
  return <Navigate to="/" state={{ from: location }} replace />;
};

