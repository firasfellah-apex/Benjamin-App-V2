import { Routes, Route } from 'react-router-dom';
import { Toaster } from 'sonner';
import { RequireAuth } from '@/components/auth/RequireAuth';
import { ViewportIndicator } from '@/components/dev/ViewportIndicator';
import { useViewport } from '@/hooks/useViewport';
import routes from './routes';

const App = () => {
  // Initialize viewport management - this is inside Router context
  useViewport();

  return (
    <>
      <Toaster position="top-center" richColors />
      <RequireAuth whitelist={["/login", "/404", "/"]}>
        <Routes>
          {routes.map((route, index) => (
            <Route
              key={index}
              path={route.path}
              element={route.element}
            />
          ))}
        </Routes>
      </RequireAuth>
      <ViewportIndicator />
    </>
  );
};

export default App;
