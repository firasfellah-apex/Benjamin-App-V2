/**
 * Viewport Management Hook
 * 
 * Provides viewport configuration based on app type:
 * - Admin: Responsive (desktop/mobile, web + app)
 * - Runner: Mobile app only (phone viewport)
 * - Customer: Mobile app only (phone viewport)
 */

import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';

export type ViewportMode = 'responsive' | 'mobile-only';

/**
 * Get viewport mode based on current route
 */
export function getViewportMode(pathname: string): ViewportMode {
  if (pathname.startsWith('/admin')) {
    return 'responsive'; // Admin: desktop/mobile, web + app
  } else if (pathname.startsWith('/runner') || pathname.startsWith('/customer')) {
    return 'mobile-only'; // Runner & Customer: mobile app only
  }
  return 'responsive'; // Default: responsive
}

/**
 * Hook to manage viewport constraints based on route
 */
export function useViewport() {
  const location = useLocation();
  const mode = getViewportMode(location.pathname);

  useEffect(() => {
    const viewportMeta = document.querySelector('meta[name="viewport"]');
    
    if (!viewportMeta) return;

    if (mode === 'mobile-only') {
      // Mobile app: prevent zoom, set mobile viewport
      viewportMeta.setAttribute(
        'content',
        'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover'
      );
      
      // Add mobile-only class to body for CSS constraints
      document.body.classList.add('mobile-app-viewport');
      document.body.classList.remove('responsive-viewport');
    } else {
      // Responsive: allow zoom, standard viewport
      viewportMeta.setAttribute(
        'content',
        'width=device-width, initial-scale=1.0, maximum-scale=5.0, user-scalable=yes'
      );
      
      // Add responsive class to body
      document.body.classList.add('responsive-viewport');
      document.body.classList.remove('mobile-app-viewport');
    }

    // Detect if we're in device emulation mode (for CSS to remove phone frame)
    // Device emulation typically has a very narrow viewport
    // Also check if DevTools device toolbar is active (viewport width matches common device sizes)
    const commonDeviceWidths = [375, 390, 393, 428, 430, 360, 414];
    const isCommonDeviceWidth = commonDeviceWidths.includes(window.innerWidth);
    const isDeviceEmulation = (window.innerWidth <= 500 && 
                              (window.navigator.userAgent.includes('Mobile') || 
                               window.matchMedia('(pointer: coarse)').matches)) ||
                              (isCommonDeviceWidth && window.innerHeight > window.innerWidth);
    
    if (mode === 'mobile-only') {
      // Set data attribute for CSS to detect device emulation
      if (isDeviceEmulation) {
        document.body.setAttribute('data-device-emulation', 'true');
      } else {
        document.body.removeAttribute('data-device-emulation');
      }
    } else {
      document.body.removeAttribute('data-device-emulation');
    }

    // Log viewport mode in development
    if (import.meta.env.DEV) {
      console.log(`[Viewport] Mode: ${mode} | Route: ${location.pathname} | Device Emulation: ${isDeviceEmulation}`);
    }

    // Cleanup on unmount
    return () => {
      // Reset to default on unmount
      if (viewportMeta) {
        viewportMeta.setAttribute('content', 'width=device-width, initial-scale=1.0');
      }
      document.body.removeAttribute('data-device-emulation');
    };
  }, [mode, location.pathname]);

  return { mode, isMobileOnly: mode === 'mobile-only' };
}

