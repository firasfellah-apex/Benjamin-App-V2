import { useEffect, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { Eye, TrendingUp, Package, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ShellCard } from "@/components/ui/ShellCard";
import { StatusChip } from "@/components/ui/StatusChip";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { getRunnerOrders, getRunnerEarningsStats } from "@/db/api";
import { useOrdersRealtime } from "@/hooks/useOrdersRealtime";
import { getRunnerPayout } from "@/lib/payouts";
import type { OrderWithDetails, Order } from "@/types/types";
import { useProfile } from "@/contexts/ProfileContext";

export default function MyDeliveries() {
  const navigate = useNavigate();
  const { profile } = useProfile();
  const [orders, setOrders] = useState<OrderWithDetails[]>([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    monthlyEarnings: 0,
    activeDeliveries: 0,
    completedThisMonth: 0,
  });
  const [statsLoading, setStatsLoading] = useState(true);

  const loadOrders = async () => {
    const data = await getRunnerOrders();
    setOrders(data);
    setLoading(false);
  };

  const loadStats = async () => {
    const earningsStats = await getRunnerEarningsStats();
    setStats(earningsStats);
    setStatsLoading(false);
  };

  useEffect(() => {
    loadOrders();
    loadStats();
  }, []);

  // Handle realtime order updates
  const handleOrderUpdate = useCallback((order: Order) => {
    setOrders((prev) => {
      const updated = prev.map((o) => (o.id === order.id ? (order as OrderWithDetails) : o));
      // Reload stats when order updates
      loadStats();
      return updated;
    });
  }, []);

  const handleOrderInsert = useCallback((order: Order) => {
    setOrders((prev) => {
      if (prev.some((o) => o.id === order.id)) return prev;
      const updated = [order as OrderWithDetails, ...prev];
      loadStats();
      return updated;
    });
  }, []);

  // Subscribe to runner's orders
  useOrdersRealtime({
    filter: { mode: 'runner', runnerId: profile?.id },
    onInsert: handleOrderInsert,
    onUpdate: handleOrderUpdate,
    enabled: !!profile,
  });

  const activeOrders = orders.filter(o => {
    const activeStatuses = ['Runner Accepted', 'Runner at ATM', 'Cash Withdrawn', 'Pending Handoff'];
    return activeStatuses.includes(o.status);
  });
  const completedOrders = orders.filter(o => o.status === "Completed");

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">My Deliveries</h1>
          <p className="text-sm text-slate-400">
            Track your delivery orders and earnings
          </p>
        </div>
        <Button 
          onClick={() => navigate("/runner/available")}
          className="bg-indigo-600 text-white hover:bg-indigo-700 rounded-xl"
        >
          View Available Orders
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <ShellCard variant="runner" className="relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-3xl" />
          <div className="relative space-y-2">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-emerald-400" />
              <p className="text-sm text-slate-400">Monthly Earnings</p>
            </div>
            {statsLoading ? (
              <div className="h-10 w-32 bg-slate-800 rounded animate-pulse" />
            ) : (
              <>
                <p className="text-4xl font-bold text-emerald-400">
                  ${stats.monthlyEarnings.toFixed(2)}
                </p>
                <p className="text-xs text-slate-500">
                  Earnings from completed deliveries this month
                </p>
              </>
            )}
          </div>
        </ShellCard>

        <ShellCard variant="runner">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Package className="h-5 w-5 text-indigo-400" />
              <p className="text-sm text-slate-400">Active Deliveries</p>
            </div>
            {statsLoading ? (
              <div className="h-10 w-16 bg-slate-800 rounded animate-pulse" />
            ) : (
              <p className="text-4xl font-bold text-white">
                {stats.activeDeliveries}
              </p>
            )}
          </div>
        </ShellCard>

        <ShellCard variant="runner">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5 text-emerald-400" />
              <p className="text-sm text-slate-400">Completed This Month</p>
            </div>
            {statsLoading ? (
              <div className="h-10 w-16 bg-slate-800 rounded animate-pulse" />
            ) : (
              <p className="text-4xl font-bold text-emerald-400">
                {stats.completedThisMonth}
              </p>
            )}
          </div>
        </ShellCard>
      </div>

      {activeOrders.length > 0 && (
        <ShellCard variant="runner">
          <div className="space-y-4">
            <div>
              <h2 className="text-lg font-semibold text-white">Active Deliveries</h2>
              <p className="text-sm text-slate-400 mt-1">
                Orders currently in progress
              </p>
            </div>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-slate-700 hover:bg-slate-800/50">
                    <TableHead className="text-slate-300">Order ID</TableHead>
                    <TableHead className="text-slate-300">Amount</TableHead>
                    <TableHead className="text-slate-300">Earnings</TableHead>
                    <TableHead className="text-slate-300">Status</TableHead>
                    <TableHead className="text-slate-300">Accepted</TableHead>
                    <TableHead className="text-right text-slate-300">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {activeOrders.map((order) => (
                    <TableRow key={order.id} className="border-slate-700 hover:bg-slate-800/50">
                      <TableCell className="font-mono text-sm text-slate-300">
                        #{order.id.slice(0, 8)}
                      </TableCell>
                      <TableCell className="font-semibold text-white">
                        ${order.requested_amount.toFixed(2)}
                      </TableCell>
                      <TableCell className="font-semibold text-emerald-400">
                        ${getRunnerPayout(order).toFixed(2)}
                      </TableCell>
                      <TableCell>
                        <StatusChip status={order.status} tone="runner" />
                      </TableCell>
                      <TableCell className="text-sm text-slate-400">
                        {order.runner_accepted_at ? new Date(order.runner_accepted_at).toLocaleString() : '-'}
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => navigate(`/runner/orders/${order.id}`)}
                          className="text-slate-300 hover:text-white hover:bg-slate-700"
                        >
                          <Eye className="mr-2 h-4 w-4" />
                          View
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        </ShellCard>
      )}

      <ShellCard variant="runner">
        <div className="space-y-4">
          <div>
            <h2 className="text-lg font-semibold text-white">Delivery History</h2>
            <p className="text-sm text-slate-400 mt-1">
              All your completed deliveries
            </p>
          </div>
          {loading ? (
            <div className="text-center py-8 text-slate-400">
              Loading deliveries...
            </div>
          ) : orders.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-slate-400 mb-4">No deliveries yet</p>
              <Button 
                onClick={() => navigate("/runner/available")}
                className="bg-indigo-600 text-white hover:bg-indigo-700 rounded-xl"
              >
                View Available Orders
              </Button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-slate-700 hover:bg-slate-800/50">
                    <TableHead className="text-slate-300">Order ID</TableHead>
                    <TableHead className="text-slate-300">Amount</TableHead>
                    <TableHead className="text-slate-300">Earnings</TableHead>
                    <TableHead className="text-slate-300">Status</TableHead>
                    <TableHead className="text-slate-300">Completed</TableHead>
                    <TableHead className="text-right text-slate-300">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {completedOrders.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-8">
                        <p className="text-slate-400 mb-4">No completed deliveries yet</p>
                        <Button 
                          onClick={() => navigate("/runner/available")}
                          className="bg-indigo-600 text-white hover:bg-indigo-700 rounded-xl"
                        >
                          View Available Orders
                        </Button>
                      </TableCell>
                    </TableRow>
                  ) : (
                    completedOrders.map((order) => (
                      <TableRow key={order.id} className="border-slate-700 hover:bg-slate-800/50">
                        <TableCell className="font-mono text-sm text-slate-300">
                          #{order.id.slice(0, 8)}
                        </TableCell>
                        <TableCell className="font-semibold text-white">
                          ${order.requested_amount.toFixed(2)}
                        </TableCell>
                        <TableCell className="font-semibold text-emerald-400">
                          ${getRunnerPayout(order).toFixed(2)}
                        </TableCell>
                        <TableCell>
                          <StatusChip status={order.status} tone="runner" />
                        </TableCell>
                        <TableCell className="text-sm text-slate-400">
                          {order.handoff_completed_at ? new Date(order.handoff_completed_at).toLocaleDateString() : '-'}
                        </TableCell>
                        <TableCell className="text-right">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => navigate(`/runner/orders/${order.id}`)}
                            className="text-slate-300 hover:text-white hover:bg-slate-700"
                          >
                            <Eye className="mr-2 h-4 w-4" />
                            View
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          )}
        </div>
      </ShellCard>
    </div>
  );
}
