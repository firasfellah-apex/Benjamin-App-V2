/**
 * Customer Home Dashboard
 * 
 * Main landing page for authenticated customers.
 * Features:
 * - Personalized greeting
 * - Delivery statistics snapshot
 * - Active order tracking card
 * - Recent order history
 * - Referral banner
 */

import { useEffect, useState, useCallback } from 'react';
import { useNavigate, Navigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useProfile } from '@/contexts/ProfileContext';
import { PageContainer } from '@/components/layout/PageContainer';
import { ShellCard } from '@/components/ui/ShellCard';
import { StatusChip } from '@/components/ui/StatusChip';
import { Button } from '@/components/ui/button';
import { supabase } from '@/db/supabase';
import { useOrdersRealtime } from '@/hooks/useOrdersRealtime';
import { isOrderFinal } from '@/lib/reveal';
import type { Order } from '@/types/types';
import { ArrowRight, Package } from 'lucide-react';

export default function CustomerHome() {
  const { user, loading: authLoading } = useAuth();
  const { profile, loading: profileLoading } = useProfile();
  const navigate = useNavigate();
  const [orders, setOrders] = useState<Order[]>([]);
  const [activeOrder, setActiveOrder] = useState<Order | null>(null);
  const [ordersLoading, setOrdersLoading] = useState(true);

  // Fetch orders when profile is available
  useEffect(() => {
    if (!profileLoading && profile) {
      fetchOrders();
    } else if (!profileLoading && !profile) {
      // Profile loading finished but no profile - still resolve loading state
      setOrdersLoading(false);
    }
  }, [profile, profileLoading]);

  const fetchOrders = async () => {
    if (!profile) {
      setOrdersLoading(false);
      return;
    }

    try {
      setOrdersLoading(true);
      const { data, error } = await supabase
        .from('orders')
        .select('*')
        .eq('customer_id', profile.id)
        .order('created_at', { ascending: false })
        .limit(10);

      if (error) throw error;

      const orderList = data || [];
      setOrders(orderList);

      // Find active order (non-final status)
      const active = orderList.find(
        o => !isOrderFinal(o.status)
      );
      setActiveOrder(active || null);
    } catch (error) {
      console.error('Error fetching orders:', error);
    } finally {
      setOrdersLoading(false);
    }
  };

  // Handle realtime order insert
  const handleOrderInsert = useCallback((order: Order) => {
    setOrders((prev) => {
      // Check if order already exists
      if (prev.some((o) => o.id === order.id)) return prev;
      // Add to the beginning and sort by created_at
      const updated = [order, ...prev]
        .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
        .slice(0, 10); // Keep only latest 10
      
      // Update active order if this is a new active order
      if (!isOrderFinal(order.status)) {
        setActiveOrder(order);
      }
      
      return updated;
    });
  }, []);

  // Handle realtime order update
  const handleOrderUpdate = useCallback((order: Order, oldOrder?: Order) => {
    console.log('[CustomerHome] Realtime update received:', {
      orderId: order.id,
      oldStatus: oldOrder?.status,
      newStatus: order.status,
    });
    
    setOrders((prev) => {
      const updated = prev.map((o) => (o.id === order.id ? order : o));
      
      // Update active order
      if (!isOrderFinal(order.status)) {
        setActiveOrder(order);
      } else {
        // If order was completed/cancelled, clear active order if it was the active one
        if (activeOrder?.id === order.id) {
          setActiveOrder(null);
        }
      }
      
      return updated;
    });
  }, [activeOrder]);

  // Subscribe to realtime updates for customer orders
  useOrdersRealtime({
    filter: { mode: 'customer', customerId: profile?.id || '' },
    onInsert: handleOrderInsert,
    onUpdate: handleOrderUpdate,
    enabled: !!profile,
  });

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour >= 5 && hour < 12) return { text: 'Good morning', emoji: '🌤️' };
    if (hour >= 12 && hour < 17) return { text: 'Good afternoon', emoji: '☀️' };
    return { text: 'Good evening', emoji: '🌙' };
  };

  const getUserName = () => {
    if (profile?.first_name) {
      return profile.first_name;
    }
    if (user?.email) {
      return user.email.split('@')[0];
    }
    return null;
  };

  // Show loading only while auth is loading
  if (authLoading) {
    return (
      <PageContainer variant="customer">
        <div className="flex h-[70vh] items-center justify-center text-sm text-gray-500">
          Loading...
        </div>
      </PageContainer>
    );
  }

  // If no user, redirect to landing (RequireAuth should handle this, but double-check)
  if (!user) {
    return <Navigate to="/" replace />;
  }

  // Calculate stats (safe even with empty orders)
  const completedOrders = orders.filter(o => o.status === 'Completed');
  const totalDelivered = completedOrders.reduce((sum, o) => sum + (o.requested_amount || 0), 0);
  const recentOrders = completedOrders.slice(0, 3);
  const hasActive = !!activeOrder;

  const getSubtitle = () => {
    if (hasActive) {
      return "Your cash is on its way. Track everything here.";
    }
    if (completedOrders.length > 0) {
      return "All your cash deliveries in one place.";
    }
    return "Skip the ATM. Request cash in seconds.";
  };

  const greeting = getGreeting();
  const userName = getUserName();

  return (
    <div className="space-y-6 pt-4">
      {/* Greeting */}
      <div className="space-y-1">
        <h1 className="text-2xl md:text-[26px] font-semibold text-black leading-tight">
          {greeting.text}{userName ? `, ${userName}` : ''}
          <span className="ml-1 text-lg">{greeting.emoji}</span>
        </h1>
        <p className="text-sm text-neutral-500">
          {getSubtitle()}
        </p>
      </div>

      {/* Your Summary Card */}
      <ShellCard variant="customer" className="bg-white rounded-3xl px-5 py-4 shadow-sm">
        <div className="space-y-4">
          <h2 className="text-lg font-semibold text-black">Your Summary</h2>
          
          {completedOrders.length > 0 ? (
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <p className="text-xs text-neutral-500">Total Delivered</p>
                <p className="text-2xl font-bold text-black">
                  ${totalDelivered.toFixed(2)}
                </p>
              </div>
              <div className="space-y-1">
                <p className="text-xs text-neutral-500">Completed Deliveries</p>
                <p className="text-2xl font-bold text-black">
                  {completedOrders.length}
                </p>
              </div>
            </div>
          ) : (
            <div className="py-6 text-center">
              <p className="text-sm text-neutral-500">
                Your summary appears after your first delivery.
              </p>
            </div>
          )}
        </div>
      </ShellCard>

      {/* Active Delivery Card */}
      {hasActive ? (
        <ShellCard variant="customer" className="bg-white rounded-3xl px-5 py-4 shadow-sm">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-black">Active Delivery</h2>
              <StatusChip status={activeOrder.status} tone="customer" />
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-neutral-500">Amount</span>
                <span className="font-semibold text-black">
                  ${activeOrder.requested_amount.toFixed(2)}
                </span>
              </div>
              {activeOrder.address_snapshot?.city && (
                <div className="flex justify-between text-sm">
                  <span className="text-neutral-500">Location</span>
                  <span className="font-medium text-black">
                    {activeOrder.address_snapshot.city}
                  </span>
                </div>
              )}
            </div>

            <Button
              onClick={() => navigate(`/customer/orders/${activeOrder.id}`)}
              className="w-full bg-black text-white rounded-full py-3 font-semibold"
            >
              Track delivery
            </Button>
          </div>
        </ShellCard>
      ) : (
        <ShellCard variant="customer" className="bg-white rounded-3xl px-5 py-4 shadow-sm">
          <div className="space-y-4">
            <h2 className="text-lg font-semibold text-black">Active Delivery</h2>
            <div className="py-8 text-center">
              <Package className="h-12 w-12 text-neutral-300 mx-auto mb-3" />
              <p className="text-sm font-medium text-black mb-1">No active delivery yet</p>
              <p className="text-xs text-neutral-500">
                Once you request cash, you'll see live tracking here.
              </p>
            </div>
          </div>
        </ShellCard>
      )}

      {/* Recent Deliveries */}
      <ShellCard variant="customer" className="bg-white rounded-3xl px-5 py-4 shadow-sm">
        <div className="space-y-4">
          <h2 className="text-lg font-semibold text-black">Recent Deliveries</h2>
          
          {recentOrders.length > 0 ? (
            <>
              <div className="space-y-3">
                {recentOrders.map((order) => (
                  <button
                    key={order.id}
                    onClick={() => navigate(`/customer/orders/${order.id}`)}
                    className="w-full flex items-center justify-between p-3 rounded-xl bg-neutral-50 transition-colors"
                  >
                    <div className="flex-1 text-left space-y-1">
                      <span className="text-sm font-semibold text-black block">
                        ${order.requested_amount.toFixed(2)}
                      </span>
                      <p className="text-xs text-neutral-500">
                        {new Date(order.created_at).toLocaleDateString('en-US', {
                          month: 'short',
                          day: 'numeric',
                          year: 'numeric'
                        })}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <StatusChip 
                        status={order.status} 
                        tone="customer"
                        className="text-[9px] px-2 py-0.5"
                      />
                      <ArrowRight className="h-4 w-4 text-neutral-400" />
                    </div>
                  </button>
                ))}
              </div>
              <Button
                variant="outline"
                onClick={() => navigate('/customer/orders')}
                className="w-full rounded-full border-black/10 text-sm mt-2"
              >
                View all deliveries
              </Button>
            </>
          ) : (
            <div className="py-8 text-center">
              <Package className="h-12 w-12 text-neutral-300 mx-auto mb-3" />
              <p className="text-sm font-medium text-black mb-1">You haven't used Benjamin yet</p>
              <p className="text-xs text-neutral-500">
                Your completed deliveries will show here.
              </p>
            </div>
          )}
        </div>
      </ShellCard>

    </div>
  );
}
